export const environment = {
  firebase: {
    apiKey: "AIzaSyCKFNpaeALw7_HhpN_J4pmmW78kiTNlW1o",
    authDomain: "auction-site-2b37e.firebaseapp.com",
    projectId: "auction-site-2b37e",
    storageBucket: "auction-site-2b37e.appspot.com",
    messagingSenderId: "630693006570",
    appId: "1:630693006570:web:ecddc0230a19370defdb93"
  },
};